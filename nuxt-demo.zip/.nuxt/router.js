import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _609ec64b = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _7e74d3ff = () => interopDefault(import('..\\pages\\post.vue' /* webpackChunkName: "pages/post" */))
const _6b579149 = () => interopDefault(import('..\\pages\\rickyAndMorty.vue' /* webpackChunkName: "pages/rickyAndMorty" */))
const _a97d3afa = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/inspire",
    component: _609ec64b,
    name: "inspire"
  }, {
    path: "/post",
    component: _7e74d3ff,
    name: "post"
  }, {
    path: "/rickyAndMorty",
    component: _6b579149,
    name: "rickyAndMorty"
  }, {
    path: "/",
    component: _a97d3afa,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
