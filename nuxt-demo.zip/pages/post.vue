<template>
  <div>
    <h1>Loly</h1>
  </div>
</template>
<script>
export default {
}
</script>
